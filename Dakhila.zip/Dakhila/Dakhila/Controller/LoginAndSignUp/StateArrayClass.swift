//
//  StateArrayClass.swift
//  Dakhila
//
//  Created by Saurabh Mishra on 21/06/17.
//  Copyright © 2017 Krishan Vir. All rights reserved.
//

import UIKit

class StateArrayClass: NSObject {
    
    var stateId : Int?
    var stateName : String?

}

//
//  SupporttTickerArrayClass.swift
//  Dakhila
//
//  Created by Saurabh Mishra on 23/06/17.
//  Copyright © 2017 Krishan Vir. All rights reserved.
//

import UIKit

class SupporttTickerArrayClass: NSObject {
    
    var TickerId : Int?
    var categoryName : String?
    var dateString : String?
    var queryString : String?
    var replyString : String?
    var statusString : String?
    var repliedByString : String?
    var repliedDate : String?
   
}

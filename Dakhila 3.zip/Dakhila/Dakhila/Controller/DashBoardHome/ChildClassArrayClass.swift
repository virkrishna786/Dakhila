//
//  ChildClassArrayClass.swift
//  Dakhila
//
//  Created by Saurabh Mishra on 02/07/17.
//  Copyright © 2017 Krishan Vir. All rights reserved.
//

import UIKit

class ChildClassArrayClass: NSObject {
    
    var classId : Int?
    var className : String?

}

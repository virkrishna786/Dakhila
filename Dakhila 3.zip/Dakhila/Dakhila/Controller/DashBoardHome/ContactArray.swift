//
//  ContactArray.swift
//  NewProjectForGit
//
//  Created by Admin media on 7/13/17.
//  Copyright © 2017 Media Mosaic service private limited. All rights reserved.
//

import UIKit

class ContactArray: NSObject {
    
    var contactId: String?
    var contactName : String?
    var contactDetai : String?
    var phoneNumber : String?

}

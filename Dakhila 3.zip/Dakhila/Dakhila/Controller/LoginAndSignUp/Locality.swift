//
//  Locality.swift
//  Dakhila
//
//  Created by Saurabh Mishra on 21/06/17.
//  Copyright © 2017 Krishan Vir. All rights reserved.
//

import UIKit

class Locality: NSObject {
    var localityId : Int?
    var localityName : String?

}
